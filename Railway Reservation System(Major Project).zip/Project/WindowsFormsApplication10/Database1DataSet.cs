﻿namespace WindowsFormsApplication10 {
    
    
    public partial class Database1DataSet {
    }
}
namespace WindowsFormsApplication10 {
    
    
    public partial class Database1DataSet {
    }
}
